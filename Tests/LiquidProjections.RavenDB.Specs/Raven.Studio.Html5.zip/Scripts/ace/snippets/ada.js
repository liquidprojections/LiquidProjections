define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./ada.snippets");
exports.scope = "ada";

});

define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./ejs.snippets");
exports.scope = "ejs";

});

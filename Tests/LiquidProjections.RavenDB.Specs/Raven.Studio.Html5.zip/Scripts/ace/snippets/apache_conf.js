define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./apache_conf.snippets");
exports.scope = "apache_conf";

});
